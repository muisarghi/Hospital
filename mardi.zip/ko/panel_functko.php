<?php


class m

{

function del()
	{
	$id=$_GET['id'];
	$alm=$_GET['alm'];
	$db=$_GET['db'];
	//$idpas=$_GET['idpas'];
	//$status=$_GET['status'];
	$masuk="DELETE FROM m_$db where id='$id'";
	$query=mysql_query($masuk);
	if($masuk)
		{
		header("Location: index.php?task=mes&pes=Data Sudah Dihapus&idpas=$idpas&status=$status&alm=$alm");
		}
	else
		{
	echo"ERROR";
		}
	
	}

function index()
	{
	$cari="SELECT *FROM pg_date ORDER BY id";
	$hasil=mysql_query($cari);
	if($hasil)
	while($dt=mysql_fetch_array($hasil))
		{
		$cbln=$dt[bln];
		$cthn=$dt[thn];
		$cbln2=$dt[bln2];
		$cthn2=$dt[thn2];

		}
		$blnn=DATE('m');
		$thnn=DATE('Y');
	echo"
	Selamat Datang di HALAMAN KAMAR OBAT RSIA MARDI WALOEJA MALANG
	<br>
	<br>
	";
	
	}


function gt_ac()
	{
	$pass=$_SESSION['pes2'];
	
	$cari="SELECT *FROM m_user where pass='$pass'";
	$hasil=mysql_query($cari);
	if($hasil)
	$data=mysql_fetch_array($hasil);
		
		$id=$data['id'];
		$nama=$data['nama'];
		$pass=$data['pass1'];
		$user=$data['user'];
		
	echo"
	
	<b>Pergantian Account Administrator</b>
	<br>
	<br>
	<form method='post' action='index.php?task=progtac'>
	<table width='50%' border='0' cellpadding='0' cellspacing='0'>
	<tr>
	<td width='20%'><font size='2'>Nama</td>
	<td>: <input type='text' name='nama' value='$nama'></td>
	</tr>
	
	<tr>
	<td width='20%'><font size='2'>Username</td>
	<td>: <input type='text' name='user' value='$user'></td>
	</tr>

	<tr>
	<td width='20%'><font size='2'>Password</td>
	<td>: <input type='text' name='pass' value='$pass'></</td>
	</tr>
	
	<tr>
	<td colspan='2' align='left'>
	<input type='hidden' name='id' value='$id'>
	<input type='submit' value='SIMPAN'>
	</td>
	</tr>
	</table>
	</form>
	";
	
	}

function progtac()
	{
	$id=$_POST['id'];
	$nama=$_POST['nama'];
	$user=$_POST['user'];
	$pass=$_POST['pass'];

	$r=MD5($pass).$id;
	$x=$id*942;
	//$y=$no_angg;
	$z='2ae2o';
	$w='3g2y2n1c2l1m';
	$pes2='3g2y2n1c2l1m'.MD5($pass).$x.'2ae2o';
	
	
	$sql = "UPDATE m_user SET nama= '$nama', user='$user', pass='$r', pass1='$pass' WHERE id='$id'";
	$result = mysql_query($sql);

	if ($result)
		{
		echo"Data Sudah Diubah, Silahkan Melakukan Login Kembali<a href='logout.php'>Logout</a>";
		}
	else{echo"ERROR";}
	}



function mes()
	{
	$id=$_GET['id'];
	//$status=$_GET['status'];
	$alm=$_GET['alm'];
	$pes=$_GET['pes'];
	
	echo"
	<form method='post' action='index.php?task=$alm'>
	<br><br>
	<b>$pes</b>, 
	<input type='hidden' name='id' value='$id'>
	
	<input type='submit' value='KEMBALI'>
	</form>
	";

	}

function konfobt()
	{
	$a1=mysql_query("select *from m_konfobt where id='1'");
	while($a=mysql_fetch_array($a1))
	{
	$per=$a[per];
	}
	echo"<br>
	<h1>
	KONFIGURASI PERSENTASE HARGA OBAT
	</h1>
	<br>
	<form method='post' action='index.php?task=pkonfobt'>
	<table class='adminlist'>
	<tr>
	<td width='50%'>
	Persentase harga obat
	</td>
	<td>:
	<input type='text' name='per' value='$per'>
	</td>
	</tr>
	<tr>
	<td colspan='2' align='center'>
	<input type='hidden' name='id' value='1'>
	<input type='submit' value='[ SIMPAN ]'>
	</td>
	</tr>
	</table>
	</form>
	";
	}

function pkonfobt()
	{
	$id=$_POST['id'];
	$per=$_POST['per'];

	$a=mysql_query("update m_konfobt set per='$per' where id='$id'");
	if($a)
		{header("location: index.php?task=konfobt&pesan=Data Sudah Diganti");}
	else
		{
		echo"error";
		}
	}

function obt()
	{
	$a1=mysql_query("select *from m_konfobt where id='1'");
	while($a=mysql_fetch_array($a1))
	{
	$per=$a[per];
	}
	$pesan=$_GET['pesan'];
	echo"
	<h1>DATA OBAT</h1>
	<br>
	<u>$pesan</u>
	<br><br>
	<form method='post' action='index.php?task=pobt'>
	<table class='adminlist'>
	<tr>
	<td>Nama Obat</td>
	<td>: <input type='text' name='nama'></td>
	</tr>
	<tr>
	<td>Harga Beli</td>
	<td>: <input type='text' name='hgbeli'></td>
	</tr>
	<tr>
	<td>Satuan</td>
	<td>: <input type='text' name='satuan'></td>
	</tr>
	<tr>
	<td colspan='2' align='center'>
	<input type='hidden' name='per' value='$per'>
	<input type='submit' value=' [ SIMPAN ]'>
	</td>
	</tr>
	</table>
	</form>
	<br>
	<br>
	<table class='adminlist'>
	<tr>
	<td>Nama</td>
	<td>Harga Beli</td>
	<td>Harga Jual</td>
	<td>Satuan</td>
	<td>Hapus</td>
	</tr>";
	$b1=mysql_query("select *from m_obt");
	while($b=mysql_fetch_array($b1))
	{
	echo"
	<tr>
	<td>$b[nama]</td>
	<td>$b[hgbeli]</td>
	<td>$b[hgjual]</td>
	<td>$b[satuan]</td>
	<td><a href='index.php?task=del&id=$b[id]&db=obt&alm=obt'>hapus</a></td>
	</tr>
	";
	}
	echo"
	</table>
	";
	}

function pobt()
	{
	$nama=$_POST['nama'];
	$hgbeli=$_POST['hgbeli'];
	$per=$_POST['per'];
	$satuan=$_POST['satuan'];
	$hgjual=$per/100*$hgbeli+$hgbeli;

	$a=mysql_query("insert into m_obt values ('', '$nama', '$hgbeli', '$hgjual', '$satuan')");
	if($a)
		{header("location: index.php?task=obt&pesan=Data Sudah Masuk");}
	else
		{echo"ror";}
	}


function cobt()
	{
	echo"
	<center><b>KONFIGURASI HARGA JUAL</b></center>
	<br><br>
	<u>$pesan</u>
	<br><br>
	<form method='post' action='index.php?task=c_obt'>
	<table class='adminlist'>
	<tr>
	<td>
	Nama Obat : 
	</td>
	
	</tr>

	<tr>
	<td width='50%'>
	
	<input type='text' id='kata' name='id' onkeyup='lihat(this.value)' size='40'>
	<div id='kotaksugest' style='position:absolute;
	background-color:#eeffee;visibility:hidden;z-index:100'>
	</div>
	
	<input type='submit' value='cari'>
	</td>
	
	</tr>
	</table>";
	}

function c_obt()
	{
	$id=$_POST['id'];
	$b1=mysql_query("select *from m_konfobt where id='1'");
	while($b=mysql_fetch_array($b1))
		{
		$per=$b[per];
		}
	$a1=mysql_query("select *from m_obt where id='$id'");
	while($a=mysql_fetch_array($a1))
		{
		$nama=$a['nama'];
		$hgbeli=$a['hgbeli'];
		$hgjual=$a['hgjual'];
		$satuan=$a['satuan'];
		}
	$hgdiskon=$per/100*$hgbeli+$hgbeli;
	echo"
	<h1>KONFIGURASI HARGA JUAL</h1><br>
	<form method='post' action='index.php?task=ec_obt'>
	<table class='adminlist'>
	<tr>
	<td>Nama Obat</td>
	<td>: <b>$nama</b></td>
	</tr>
	<tr>
	<td>Harga Beli</td>
	<td>: <b>$hgbeli</b></td>
	</tr>
	<tr>
	<td>Harga Diskon</td>
	<td>: <b>$hgdiskon</b></td>
	</tr>
	<tr>
	<td>Harga Jual</td>
	<td>: <input type='text' name='hgjual' value='$hgjual'></td>
	</tr>
	<tr>
	<td>Satuan</td>
	<td>: <input type='text' name='satuan' value='$satuan'></td>
	</tr>
	<tr>
	<td colspan='2' align='center'>
	<input type='hidden' name='id' value='$id'>
	<input type='submit' value=' [ SIMPAN ]'>
	</td>
	</tr>
	</table>
	</form>";

	}

function ec_obt()
	{
	$id=$_POST['id'];
	
	$hgjual=$_POST['hgjual'];
	
	$a=mysql_query("update m_obt set hgjual='$hgjual' where id='$id'");
	if($a)
		{
		header("location: index.php?task=mes&pes=Data Sudah Diganti&id=$id&alm=c_obt");
		}
	else{echo"error";}
	}

function retobt()
	{
	$pesan=$_GET['pesan'];
	$skr=DATE('d-m-Y');
	echo"<br>
	<h1>Retur Obat</h1>
	<br>
	<u>$pesan</u>
	<br><br>
	<form method='post' action='index.php?task=pretobt'>
	<table class='adminlist'>
	<tr>
	<td width='30%'>Nama Obat</td>
	<td>: 
	<input type='text' id='kata' name='id' onkeyup='lihat(this.value)' size='40'>
	<div id='kotaksugest' style='position:absolute;
	background-color:#eeffee;visibility:hidden;z-index:100'>
	</div>
	</td>
	</tr>
	
	<tr>
	<td>Jml Retur</td>
	<td>: <input type='text' name='retur' size='40'></td>
	</tr>
	
	<tr>
	<td>Satuan</td>
	<td>: <input type='text' name='satuan' size='40'></td>
	</tr>

	<tr>
	<td>Tanggal</td>
	<td>: <input type='text' name='tglretur' size='40' value='$skr'></td>
	</tr>
	
	<tr>
	<td colspan='2' align='center'>
	<input type='submit' value='[ SIMPAN ]'>
	</td>
	</tr>

	</table>
	</form>
	<br>
	<br>
	<table class='adminlist'>
	<tr>
	<td>Tgl</td>
	<td>Obat</td>
	<td>Jml Retur</td>
	<td>Satuan</td>
	<td>Jml Kembali</td>
	<td>Tgl Kembali</td>
	<td>Hapus</td>
	</tr>
	";
	$a1=mysql_query("select *from m_returobt order by id DESC");
	while($a=mysql_fetch_array($a1))
	{
	echo"
	<tr>
	<td><a href='index.php?task=eretobt&id=$a[id]'>$a[tglretur]</a></td>
	<td>";
	//$obt=$a[idobt];
	$c1=mysql_query("select *from m_obt where id='$a[idobt]'");
	while($c=mysql_fetch_array($c1))
	{$nmobt=$c[nama];}
	echo"$nmobt</td>
	<td>$a[retur]</td>
	<td>$a[satuan]</td>
	<td>$a[kembali]</td>
	<td>$a[tglkembali]</td>
	<td><a href='index.php?task=del&id=$c[id]&db=returobt&alm=retobt'>hapus</a></td>
	</tr>
	";
	}
	echo"
	</table>
	";
	}

function pretobt()
	{
	$idobt=$_POST['id'];
	$retur=$_POST['retur'];
	$satuan=$_POST['satuan'];
	$tglretur=$_POST['tglretur'];
	$a=mysql_query("insert into m_returobt values ('', '$idobt', '$retur', '', '$tglretur', '', '$satuan')");
	if($a)
		{header ("location: index.php?task=retobt&pesan=Data Sudah Masuk");}
	else{echo"error";}
	}

function eretobt()
	{
	$id=$_GET['id'];
	$skr=date('d-m-Y');
	$a1=mysql_query("select *from m_returobt where id='$id'");
	while ($a=mysql_fetch_array($a1))
		{
		$idobt=$a[idobt];
		$retur=$a[retur];
		$tglretur=$a[tglretur];
		$kembali=$a[kembali];
		$tgkembali=$a[tglkembali];
		$satuan=$a[satuan];
		}
	$b1=mysql_query("select *from m_obt where id='$idobt'");
	while($b=mysql_fetch_array($b1))
		{$nama=$b[nama];}
	echo"
	<form method='post' action='index.php?task=peretobt'>
	<table class='adminlist'>
	<tr>
	<td width='30%'>Nama Obat</td>
	<td>: <b>$nama</b>
	</td>
	</tr>
	
	<tr>
	<td>Jml Retur</td>
	<td>: <input type='text' name='retur' size='40' value='$retur'></td>
	</tr>
	
	<tr>
	<td>Tanggal</td>
	<td>: <input type='text' name='tglretur' size='40' value='$tglretur'></td>
	</tr>

	<tr>
	<td>Kembali</td>
	<td>: <input type='text' name='kembali' size='40' value='$kembali'></td>
	</tr>
	
	<tr>
	<td>Tanggal Kembali</td>
	<td>: <input type='text' name='tglkembali' size='40' value='$tglkembali'></td>
	</tr>

	<tr>
	<td>Satuan</td>
	<td>: <input type='text' name='satuan' size='40' value='$satuan'></td>
	</tr>
	
	<tr>
	<td colspan='2'>
	<input type='hidden' name='id' value='$id'>
	<input type='submit' value='[ GANTI ]'>
	</td>
	</tr>

	</table>
	</form>
	
	";
	
	}

function peretobt()
	{
	$id=$_POST['id'];
	//$idobt=$_POST['id'];
	$retur=$_POST['retur'];
	$satuan=$_POST['satuan'];
	$tglretur=$_POST['tglretur'];
	$tglkembali=$_POST['tglkembali'];
	$kembali=$_POST['kembali'];
	$a=mysql_query("update m_returobt set retur='$retur', kembali='$kembali', tglretur='$tglretur', tglkembali='$tglkembali', satuan='$satuan' where id='$id'");
	if($a)
		{header ("location: index.php?task=retobt&pesan=Data Sudah Diganti");}
	else{echo"error";}
	}

function hlgobt()
	{
	$tgl=DATE('d-m-Y');
	echo"<br>
	<h1>DATA OBAT HILANG/ RUSAK</h1>
	<br>
	<u>$pesan</u>
	<br><br>
	<form method='post' action='index.php?task=phlgobt'>
	<table class='adminlist'>
	<tr>
	<td>Nama Obat</td>
	<td>Jumlah</td>
	</tr>
	<tr>
	<td>
	<input type='text' id='kata' name='id' onkeyup='lihat(this.value)' size='40'>
	<div id='kotaksugest' style='position:absolute;
	background-color:#eeffee;visibility:hidden;z-index:100'>
	</div>
	</td>
	<td>
	<input type='text' name='jml'>
	</td>
	</tr>
	<tr>
	<td align='center' colspan='2'>
	<input type='hidden' name='tgl' value='$tgl'>
	<input type='submit' value='[ SIMPAN ]'>
	</td>
	</tr>
	</table>
	</form>
	";
	///////////DATA
	echo"
	<br><br>
	<table class='adminlist'>
	<tr>
	<td>Tanggal</td>
	<td>Nama Obat</td>
	<td>Jumlah</td>
	<td>Hapus</td>
	</tr>
	";
	$a1=mysql_query("select *from m_obthlg");
	while($a=mysql_fetch_array($a1))
		{
		echo"
		<tr>
		<td><a href='index.php?task=ehlgobt&id=$a[id]'>$a[tgl]</a></td>
		<td>$a[idobt]</td>
		<td>$a[jml]</td>
		<td><a href='index.php?task=del&id=$a[id]&db=obthlg&alm=hlgobt'>hapus</td>
		</tr>
		";
		}
	echo"
	</table>
	";
	}

function phlgobt()
	{
	$obt=$_POST['id'];
	$jml=$_POST['jml'];
	$tgl=$_POST['tgl'];
	$a=mysql_query("insert into m_obthlg values ('', '$obt', '$jml', '$tgl')");
	if($a)
		{header("location: index.php?task=hlgobt&pesan=Data Sudah Masuk");}
	else
		{echo"error";}
	}

function ehlgobt()
	{
	$id=$_GET['id'];
	$a1=mysql_query("select *from m_obthlg where id='$id'");
	while ($a=mysql_fetch_array($a1))
		{
		$tgl=$a[tgl];
		$idobt=$a[idobt];
		$jml=$a[jml];
		}
	$b1=mysql_query("select *from m_obt where id='$idobt'");
	while ($b=mysql_fetch_array($b1))
		{
		$nama=$b[nama];
		}
	
	echo"
	<br>
	<form method='post' action='index.php?task=pehlgobt'>
	<table class='adminlist'>
	<tr>
	<td>Tanggal</td>
	<td>Nama Obat</td>
	<td>Jumlah</td>
	</tr>
	<tr>
	<td>$tgl</td>
	<td>
	$nama
	</td>
	<td>
	<input type='text' name='jml' value='$jml'>
	</td>
	</tr>
	<tr>
	<td align='center' colspan='2'>
	<input type='hidden' name='id' value='$id'>
	<input type='submit' value='[ GANTI ]'>
	</td>
	</tr>
	</table>
	</form>
	";
	}

function pehlgobt()
	{
	$id=$_POST['id'];
	$jml=$_POST['jml'];
	$a=mysql_query("update m_obthlg set jml='$jml' where id='$id'");
	if($a)
		{header("location: index.php?task=hlgobt&pesan=Data Sudah Diganti");}
	else
		{echo"error";}
	}

function alkesmt()
	{
	$pesan=$_GET['pesan'];
	$tgl=DATE('d-m-Y');
	echo"
	<br>
	<h1>PENGAJUAN PERMINTAAN OBAT/ ALKES</h1>
	<br>
	<u>$pesan</u>
	<br><br>
	<table class='adminlist'>
	<tr>
	<td>Unit</td>
	<td>NO</td>
	<td>Tgl</td>
	<td>Unit</td>
	<td>Pemberi/ Tgl</td>
	<td>Penerima/ Tgl</td>
	<td>Obat</td>
	
	</tr>
	";
	$a1=mysql_query("select *from m_alkesmt order by id DESC");
	while ($a=mysql_fetch_array($a1))
	{
	echo"
	<tr>
	<td><a href='index.php?task=ealkesmt&id=$a[id]'>$a[unit]</a></td>
	<td>$a[no]</td>
	<td>$a[tgl]</td>
	<td>$a[unit]</td>
	<td>$a[beri]/ $a[beritgl]</td>
	<td>$a[trm]/ $a[trmtgl]</td>
	<td><a href='index.php?task=alkes_mt&idtr=$a[id]'>Obat</a></td>
	
	</tr>
	";
	}
	
	echo"
	</table>
	<br><br>
	";

	}

function palkesmt()
	{
	$unit=$_POST['unit'];
	$no=$_POST['no'];
	$tgl=$_POST['tgl'];
	$beri=$_POST['beri'];
	$beritgl=$_POST['beritgl'];
	$trm=$_POST['trm'];
	$trmtgl=$_POST['trmtgl'];
	$a=mysql_query("insert into m_alkesmt values ('', '$unit', '$no', '$tgl', '$beri', '$beritgl', '$trm', '$trmtgl')");
	if ($a)
	{header ("Location: index.php?task=alkesmt&pesan=Data Sudah Masuk");}
	else
		{
	echo"ror";}
	}

function ealkesmt()
	{
	$id=$_GET['id'];
	$a1=mysql_query("select *from m_alkesmt where id='$id'");
	while($a=mysql_fetch_array($a1))
	{
	$unit=$a['unit'];
	$no=$a['no'];
	$tgl=$a['tgl'];
	$beri=$a['beri'];
	$beritgl=$a['beritgl'];
	$trm=$a['trm'];
	$trmtgl=$a['trmtgl'];
	}
	echo"
	<form method='post' action='index.php?task=ealkesmt2'>
	<table class='adminlist'>
	<tr>
	<td width='20%'>
	Unit
	</td>
	<td>
	: $unit
	</td>
	</tr>

	<tr>
	<td width='20%'>
	NO
	</td>
	<td>
	: $no
	</td>
	</tr>

	<tr>
	<td width='20%'>
	Tanggal
	</td>
	<td>
	: $tgl
	</td>
	</tr>
	
	<tr>
	<td width='20%'>
	Diberikan Oleh:
	</td>
	<td>
	: <input type='text' name='beri' value='$beri'>
	</td>
	</tr>

	<tr>
	<td width='20%'>
	Diberikan Tgl:
	</td>
	<td>
	: <input type='text' name='beritgl' value='$beritgl'>
	</td>
	</tr>
	<tr>
	<td width='20%'>
	Diterima Oleh:
	</td>
	<td>
	: $trm
	</td>
	</tr>
	<tr>
	<td width='20%'>
	Diterima Tgl:
	</td>
	<td>
	: $trmtgl
	</td>
	</tr>

	<tr>
	<td colspan='2'>
	<input type='hidden' name='id' value='$id'>
	<input type='submit' value='[ GANTI ]'>
	</td>
	</tr>
	</table>
	</form>
	";
	}

function ealkesmt2()
	{
	$id=$_POST['id'];
	//$unit=$_POST['unit'];
	//$no=$_POST['no'];
	//$tgl=$_POST['tgl'];
	$beri=$_POST['beri'];
	$beritgl=$_POST['beritgl'];
	//$trm=$_POST['trm'];
	//$trmtgl=$_POST['trmtgl'];
	$a=mysql_query("update m_alkesmt set beri='$beri', beritgl='$beritgl' where id='$id'");
	if ($a)
	{header ("Location: index.php?task=alkesmt&pesan=Data Sudah Diganti");}
	else
		{
	echo"ror";}
	}


function alkes_mt()
	{
	$idtr=$_GET['idtr'];
	$pesan=$_GET['pesan'];
	echo"
	<h1>PENGAJUAN PERMINTAAN OBAT/ ALKES</h1>
	<br>
	<u>$pesan</u>
	<br><br>
	<table class='adminlist'>
	<tr>
	<td>Unit</td>
	<td>NO</td>
	<td>Tgl</td>
	
	</tr>
	";
	$a1=mysql_query("select *from m_alkesmt where id='$idtr'");
	while ($a=mysql_fetch_array($a1))
	{
	$unit=$a['unit'];
	$no=$a['no'];
	$tgl=$a['tgl'];
	$beri=$a['beri'];
	$beritgl=$a['beritgl'];
	$trm=$a['trm'];
	$trmtgl=$a['trmtgl'];
	}
	echo"
	<tr>
	<td>$unit</td>
	<td>$no</td>
	<td>$tgl</td>
	</tr>
	";
	
	
	echo"
	</table>
	
	

	<table class='adminlist'>
	<tr>
	<td>Jenis/ Nama <br> Obat/ Alkes</td>
	<td>Permintaan</td>
	<td>Realisasi</td>
	<td>Satuan</td>
	<td>Jml Harga</td>
	<td>Keterangan</td>
	<td>Status</td>
	
	</tr>
	";
	$b1=mysql_query("select *from m_alkesmt2 where idtr='$idtr'");
	while ($b=mysql_fetch_array($b1))
	{
	echo"
	<tr>
	<td><a href='index.php?task=ealkes_mt&id=$b[id]&idtr=$idtr'>";
	$obt=$b[idobt];
	$c1=mysql_query("select *from m_obt where id='$obt'");
	while($c=mysql_fetch_array($c1))
		{
		$nm=$c[nama];
		}
	echo"$nm
	</a></td>
	<td>$b[jmlmt]</td>
	<td>$b[jmlreal]</td>
	<td>$b[hgst]</td>
	<td>$b[hgjml]</td>
	<td>$b[ket]</td>
	<td>$b[status]</td>
	
	</tr>
	";
	}

	echo"
	</table>
	<br><br>
	<table class='adminlist'>
	<tr>
	<td width='50%' align='center'>
	Diberikan Oleh:
	</td>
	<td width='50%' align='center'>
	Diterima Oleh:
	</td>
	</tr>

	<tr>
	<td width='50%' align='center'>
	$beri
	<br>
	Tanggal: $beritgl
	</td>
	<td width='50%' align='center'>
	$trm
	<br>
	Tanggal: $trmtgl
	</td>
	</tr>
	</table>
	";
	}

function dalkes_mt()
	{
	$idtr=$_GET['idtr'];
	$id=$_GET['id'];
	$alm=$_GET['alm'];
	$db=$_GET['db'];
	$a=mysql_query("delete from m_$db where id='$id'");
	if($a){header ("location: index.php?task=$alm&idtr=$idtr&pesan=Data Sudah Dihapus");}
	else
		{echo"error";}
	}

function palkes_mt()
	{
	$idtr=$_POST['idtr'];
	$nm=$_POST['nm'];
	$jmlmt=$_POST['jmlmt'];
	$jmlreal=$_POST['jmlreal'];
	$hgst=$_POST['hgst'];
	$hgjml=$_POST['hgjml'];
	$ket=$_POST['ket'];
	$a=mysql_query("insert into m_alkesmt2 values ('', '$idtr', '$nm', '$jmlmt', '$jmlreal', '$hgst', '$hgjml', '$ket', 'Belum')");
	if ($a)
	{header ("Location: index.php?task=alkes_mt&idtr=$idtr&pesan=Data Sudah Masuk");}
	else
		{
	echo"ror";}
	}

function ealkes_mt()
	{
	$id=$_GET['id'];
	$idtr=$_GET['idtr'];
	echo"
	<table class='adminlist'>
	<tr>
	<td>Jenis/ Nama <br> Obat/ Alkes</td>
	<td>Permintaan</td>
	<td>Realisasi</td>
	<td>Satuan</td>
	<td>Jml Harga</td>
	<td>Keterangan</td>
	<td>Status</td>
	</tr>
	";
	$b1=mysql_query("select *from m_alkesmt2 where id='$id'");
	while ($b=mysql_fetch_array($b1))
	{
	//$idtr=$b['idtr'];
	$nm=$b['nm'];
	$jmlmt=$b['jmlmt'];
	$jmlreal=$b['jmlreal'];
	$hgst=$b['hgst'];
	$hgjml=$b['hgjml'];
	$ket=$b['ket'];
	$status=$b['status'];
	}
	echo"
	<form method='post' action='index.php?task=ealkes_mt2'>
	<tr>
	<td>$nm</td>
	<td>$jmlmt</td>
	<td><input type='text' name='jmlreal' value='$jmlreal'></td>
	<td>$hgst</td>
	<td>$hgjml</td>
	<td>$ket</td>
	<td>
	<select name=''>
	<option value='$status'>$status</option>
	<option value='Belum'>Belum</option>
	<option value='Terkirim'>Terkirim</option>
	</select>
	</td>
	</tr>

	<tr>
	<td colspan='6'>
	<input type='hidden' name='id' value='$id'>
	<input type='hidden' name='idtr' value='$idtr'>
	<input type='submit' value='[ GANTI ]'>
	</form>
	</td>
	</tr>
	</table>
	";
	}



function ealkes_mt2()
	{
	$id=$_POST['id'];
	$idtr=$_POST['idtr'];
	//$nm=$_POST['nm'];
	//$jmlmt=$_POST['jmlmt'];
	$jmlreal=$_POST['jmlreal'];
	//$hgst=$_POST['hgst'];
	//$hgjml=$_POST['hgjml'];
	//$ket=$_POST['ket'];
	$status=$_POST['status'];
	$a=mysql_query("update m_alkesmt2 set jmlreal='$jmlreal', status='$status' where id='$id'");
	if ($a)
	{header ("Location: index.php?task=alkes_mt&idtr=$idtr&pesan=Data Sudah Diganti");}
	else
		{echo"ror";}
	}

function delalkes()
	{
	$id=$_GET['id'];
	$ada = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM m_alkesmt2 where idtr='$id'"),0);
	if($ada=='0')
		{
		$a=mysql_query("delete from m_alkesmt where id='$id'");
		if($a){header ("location: index.php?task=alkesmt&pesan=Data Sudah Dihapus");}
		else{echo"error";}
		}
	else
		{
		$b=mysql_query("delete from m_alkesmt2 where idtr='$id'");
		$a=mysql_query("delete from m_alkesmt where id='$id'");
		if($a and $b){header ("location: index.php?task=alkesmt&pesan=Data-data Sudah Dihapus");}
		else{echo"error";}
		}
	}

}
?>