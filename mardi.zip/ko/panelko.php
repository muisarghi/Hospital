<?php
include('../inc/inc.php');

include("panel_functko.php");



	$task=$_GET['task'];
	switch($task)
	{
	case 'index':
	m::index($option);
	break;
	case 'dtdr':
	m::dtdr($option);
	break;
	case 'cariin':
	m::cariin($option);
	break;
	case 'mes':
	m::mes($option);
	break;
	case 'del':
	m::del($option);
	break;
	
	
	//ACCOUNT ADMIN
	case 'gt_ac':
	m::gt_ac($option);
	break;
	case 'progtac':
	m::progtac($option);
	break;
	//////////////////////////
	case 'konfobt':
	m::konfobt($option);
	break;
	case 'pkonfobt':
	m::pkonfobt($option);
	break;
	case 'obt':
	m::obt($option);
	break;
	case 'pobt':
	m::pobt($option);
	break;
	case 'cobt':
	m::cobt($option);
	break;
	case 'c_obt':
	m::c_obt($option);
	break;
	case 'ec_obt':
	m::ec_obt($option);
	break;
	case 'retobt':
	m::retobt($option);
	break;
	case 'pretobt':
	m::pretobt($option);
	break;
	case 'eretobt':
	m::eretobt($option);
	break;
	case 'peretobt':
	m::peretobt($option);
	break;
	case 'hlgobt':
	m::hlgobt($option);
	break;
	case 'phlgobt':
	m::phlgobt($option);
	break;
	case 'ehlgobt':
	m::ehlgobt($option);
	break;
	case 'pehlgobt':
	m::pehlgobt($option);
	break;

	case 'alkesmt':
	m::alkesmt($option);
	break;
	case 'palkesmt':
	m::palkesmt($option);
	break;
	case 'ealkesmt':
	m::ealkesmt($option);
	break;
	case 'ealkesmt2':
	m::ealkesmt2($option);
	break;
	case 'alkes_mt':
	m::alkes_mt($option);
	break;
	case 'palkes_mt':
	m::palkes_mt($option);
	break;
	case 'ealkes_mt':
	m::ealkes_mt($option);
	break;
	case 'ealkes_mt2':
	m::ealkes_mt2($option);
	break;
	case 'delalkes':
	m::delalkes($option);
	break;
	case 'dalkes_mt':
	m::dalkes_mt($option);
	break;
	default:
	m::index($option);
	break;
	}


?>